
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class Admin extends JFrame implements ActionListener,ItemListener,FocusListener{

	JTabbedPane jtp;
	JPanel p1,p2,p3,ad,ad1,ad2,fm;
	JButton bb2,bb3,bb4,badd,bdel,refresh;
	JLabel doc,doc1,doc2,l1,l2,l3,l4,l5,l6,l7,l8,msgl1,msgl2,msgl3,msgl4,msgl5;
	JComboBox jcb,jcb1;
	JTextField tf1,tf2,tf3,tf5,tf6;
	JRadioButton rb1,rb2;
	
	JCheckBox jchk;
	
	JTable docTable,docTable1;
	JScrollPane jsp,jsp1;
	
	String[] colHeads={"Doctor_id","Name","Age","Gender","Specialization","Phone_no","Marital_status"};
	String[] colHeads1={"Patient id","Name","Email","Phone number","Gender","Specialist","Appointment"};
	int f1=0,f2=0,f3=0,f4=0,f5=0;
	String gender;
	String id,name,age,spec,phone,marital,joining;
	
	Admin()
	{
		jtp=new JTabbedPane();
		p1=new JPanel(null);
		p2=new JPanel(null);
		p3=new JPanel(null);
		jtp.addTab("Check Details of Doctors",p1);
		jtp.addTab("Check Details of Patients",p2);
		jtp.addTab("Add/Delete Doctor",p3);
		add(jtp);
		
		
		ad=new JPanel(null);
		ad.setBackground(Color.BLUE);
		ad.setBounds(0,25,1500,50);
		p1.add(ad);
		doc=new JLabel("View Doctors");
		doc.setFont(new Font("Serif",Font.BOLD,20));
		doc.setBounds(40,10,200,30);
		ad.add(doc);
		
		refresh=new JButton("Refresh");
		refresh.setBounds(1100,15,80,20);
		ad.add(refresh);
		refresh.addActionListener(this);
		
		bb2=new JButton("Logout");
		bb2.addActionListener(this);
		bb2.setBounds(1200,15,80,20);
		ad.add(bb2);
		
		ad1=new JPanel(null);
		ad1.setBackground(Color.BLUE);
		ad1.setBounds(0,25,1500,50);
		p2.add(ad1);
		doc1=new JLabel("View Patients");
		doc1.setFont(new Font("Serif",Font.BOLD,20));
		doc1.setBounds(40,10,200,30);
		ad1.add(doc1);
		
		bb3=new JButton("Logout");
		bb3.addActionListener(this);
		bb3.setBounds(1200,15,80,20);
		ad1.add(bb3);
		
		p2.add(ad1);
		
		
		
		addData();
		jsp.setBounds(10,100,1330,800);
		p1.add(jsp);
		
		
		
		addData1();
		jsp1.setBounds(10,100,1330,800);
		p2.add(jsp1);
		
		
		
		ad2=new JPanel(null);
		ad2.setBackground(Color.BLUE);
		ad2.setBounds(0,25,1500,50);
		p3.add(ad2);
		doc2=new JLabel("Add/Delete Doctor");
		doc2.setFont(new Font("Serif",Font.BOLD,20));
		doc2.setBounds(40,10,200,30);
		ad2.add(doc2);
		
		bb4=new JButton("Logout");
		bb4.addActionListener(this);
		bb4.setBounds(1200,15,80,20);
		ad2.add(bb4);
		
		p3.add(ad2);
	
		
		badd=new JButton("ADD");
		badd.setBounds(1200,100,80,20);
		p3.add(badd);
		badd.addActionListener(this);
		bdel=new JButton("DELETE");
		bdel.setBounds(1200,130,80,20);
		p3.add(bdel);
		bdel.setEnabled(false);
		bdel.addActionListener(this);
		
		
		
		fm=new JPanel(null);
		fm.setBounds(30,100,1100,570);
		p3.add(fm);
		fm.setBackground(new Color(0, 204, 204));
		
		jchk=new JCheckBox("Want to delete records?");
		jchk.setBounds(90,20,200,20);
		fm.add(jchk);
		jchk.addItemListener(this);
		
		l1=new JLabel("Doctor ID");
		l2=new JLabel("Name");
		l3=new JLabel("Age");
		l4=new JLabel("Gender");
		l5=new JLabel("Specialization");
		l6=new JLabel("Phone No.");
		l7=new JLabel("Marital Status");
		//l8=new JLabel("Joining Date");
		
		l1.setBounds(90,60,140,40);
		l1.setFont(new Font("Serif",Font.BOLD,20));
		l2.setBounds(90,120,140,40);
		l2.setFont(new Font("Serif",Font.BOLD,20));
		l3.setBounds(90,178,140,40);
		l3.setFont(new Font("Serif",Font.BOLD,20));
		l4.setBounds(90,230,140,40);
		l4.setFont(new Font("Serif",Font.BOLD,20));
		l5.setBounds(90,285,140,40);
		l5.setFont(new Font("Serif",Font.BOLD,20));
		l6.setBounds(90,343,140,40);
		l6.setFont(new Font("Serif",Font.BOLD,20));
		l7.setBounds(90,400,140,40);
		l7.setFont(new Font("Serif",Font.BOLD,20));
		//l8.setBounds(90,455,140,40);
		//l8.setFont(new Font("Serif",Font.BOLD,20));
		fm.add(l1);
		fm.add(l2);
		fm.add(l3);
		fm.add(l4);
		fm.add(l5);
		fm.add(l6);
		fm.add(l7);
		//fm.add(l8);
		
		tf1=new JTextField();
		tf2=new JTextField();
		tf3=new JTextField();
		//tf4=new JTextField();
		tf5=new JTextField();
		//tf6=new JTextField();
		tf1.setBounds(300,60,200,30);
		tf2.setBounds(300,120,200,30);
		tf3.setBounds(300,178,200,30);
		//tf4.setBounds(300,230,200,30);
		tf5.setBounds(300,350,200,30);
		//tf6.setBounds(300,460,200,30);
		fm.add(tf1);
		fm.add(tf2);
		fm.add(tf3);
		//fm.add(tf4);
		fm.add(tf5);
		//fm.add(tf6);
		
		tf1.addFocusListener(this);
		tf2.addFocusListener(this);
		tf3.addFocusListener(this);
		tf5.addFocusListener(this);
		//tf6.addFocusListener(this);
		
		ButtonGroup bg=new ButtonGroup();
		
		rb1=new JRadioButton("Male");
		rb2=new JRadioButton("Female");
		rb1.setBounds(300,240,70,20);
		rb2.setBounds(400,240,70,20);
		bg.add(rb1);
		bg.add(rb2);
		fm.add(rb1);
		fm.add(rb2);
		rb1.setSelected(true);
		
		//String sp[]= {"General Physician","Gynecologist","Pediatrician","Dermatologist","ENT Doctor","Cardiologist","Nuerologist","Dentist","Ophthalmologist"};
		jcb=new JComboBox();
		
		jcb.addItem("General Physician");
		jcb.addItem("Gynecologist");
		jcb.addItem("Pediatrician");
		jcb.addItem("Dermatologist");
		jcb.addItem("ENT Doctor");
		jcb.addItem("Cardiologist");
		jcb.addItem("Nuerologist");
		jcb.addItem("Dentist");
		jcb.addItem("Ophthalmologist");
		jcb.setBounds(300,290,200,30);
		fm.add(jcb);
		
		jcb1=new JComboBox();
		jcb1.addItem("Married");
		jcb1.addItem("Unmarried");
		jcb1.setBounds(300,407,140,30);
		fm.add(jcb1);
		
		
		msgl1=new JLabel("Enter a valid ID");
		msgl2=new JLabel("Enter a valid name");
		msgl3=new JLabel("Enter a valid age");
		msgl4=new JLabel("Enter a valid Ph No.");
		//msgl5=new JLabel("Enter a valid date");
		msgl1.setBounds(550,60,200,30);
		msgl2.setBounds(550,120,200,30);
		msgl3.setBounds(550,175,200,30);
		msgl4.setBounds(550,350,200,30);
		//msgl5.setBounds(550,458,200,30);
		
		msgl1.setVisible(false);
		msgl2.setVisible(false);
		msgl3.setVisible(false);
		msgl4.setVisible(false);
		//msgl5.setVisible(false);
		fm.add(msgl1);
		fm.add(msgl2);
		fm.add(msgl3);
		fm.add(msgl4);
		//fm.add(msgl5);
		
		setTitle("Admin");
		setExtendedState(JFrame.MAXIMIZED_BOTH);
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);		
	}
	
	
	public static void main(String args[])
	{
		new Admin();
	}

	@Override
	public void actionPerformed(ActionEvent ae) {
		// TODO Auto-generated method stub
		if(ae.getSource()==bb2||ae.getSource()==bb3||ae.getSource()==bb4)
		{
			new AdminLogin();
			setVisible(false);
		}
		
		else if(ae.getSource()==refresh)
		{
			new Admin();
			setVisible(false);
		}
	
		
		else if(ae.getSource()==badd)
		{
			if(f1==1&&f2==1&&f3==1&&f4==1/*&&f5==1*/)
			{
				
				 if((rb1.isSelected()==true)) 
					{
						
						gender="male";
						
					}
					 else if ((rb2.isSelected()==true))
					 {
						 
						 gender="female";
					 }
					
					 else
					 {
				if((rb1.isSelected()==false) && (rb2.isSelected()==false))
				{
					JOptionPane.showMessageDialog(null,"Please select Radio button");
				}
					 }
				
				try 
				{
					Class.forName("com.mysql.jdbc.Driver");
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hospitaldb","root","");
				if(con ==null)
					JOptionPane.showMessageDialog(null,"Please select Radio button");
				
				PreparedStatement stmt=con.prepareStatement("Insert into doctor(Doc_id,Name,Age,Gender,Specialization,Phn_no,Maritial_status/*,Joining_date*/) VALUES(?,?,?,?,?,?,?)");
				
				
				stmt.setInt(1, Integer.parseInt(tf1.getText()));
				
				stmt.setString(2, tf2.getText());
				stmt.setInt(3, Integer.parseInt(tf3.getText()));
				stmt.setString(4,gender);
				stmt.setString(5,(String) jcb.getSelectedItem());
				
				stmt.setInt(6,Integer.parseInt(tf5.getText()));
				stmt.setString(7,(String) jcb1.getSelectedItem());
				//stmt.setString(8,tf6.getText());
				
				stmt.executeUpdate();
					
				id=tf1.getText();
				name=tf2.getText();
				
				
				JOptionPane.showMessageDialog(null,"Your details are saved\n"+"Doctor id="+id+"\nName="+name);
				//tf4.setText(size+"");
				
				clear();
				con.close();
				
				
				}catch(Exception e)
				{
					
				}
			}
			
		}
		else if(ae.getSource()==bdel)
		{
			try 
			{
				Class.forName("com.mysql.jdbc.Driver");
				Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hospitaldb","root","");
				if(con==null)
				{
					System.out.println("no connection");
					
				}
				int id;
				id=Integer.parseInt(tf1.getText());
				PreparedStatement stmt=con.prepareStatement("delete from doctor where Doc_id =?");
				
				stmt.setInt(1,id);
				int i=stmt.executeUpdate();
				JOptionPane.showMessageDialog(null,"Your data is deleted");
				
				clear();
				
				con.close();
			
			}catch(Exception e)
			{
				System.out.println(e);
			}
			
		}
	
		
		
	}

	@Override
	public void itemStateChanged(ItemEvent ie) {
		// TODO Auto-generated method stub
		if(jchk.isSelected())
		{
			
			badd.setEnabled(false);
			bdel.setEnabled(true);
			tf2.setEditable(false);
			tf3.setEditable(false);
			tf5.setEditable(false);
			//tf6.setEditable(false);
			jcb.setEnabled(false);
			jcb1.setEnabled(false);
			rb1.setEnabled(false);
			rb2.setEnabled(false);
		}
		else
		{
			badd.setEnabled(true);
			bdel.setEnabled(false);
			tf2.setEditable(true);
			tf3.setEditable(true);
			tf5.setEditable(true);
			//tf6.setEditable(true);
			jcb.setEnabled(true);
			jcb1.setEnabled(true);
			rb1.setEnabled(true);
			rb2.setEnabled(true);
		}
	}

	@Override
	public void focusGained(FocusEvent fe) {
		// TODO Auto-generated method stub
		if(fe.getSource()==tf1&&jchk.isSelected()==false)
		{
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hospitaldb","root","");
		if(con ==null)
			System.out.println("no connection");
		
		Statement stmt=con.createStatement();
		ResultSet rs=stmt.executeQuery("select * from doctor");
			int count=0;
			while(rs.next())
			{
				count++;
			}
			count++;
		
		tf1.setText(count+"");
		tf1.setEditable(false);
		con.close();
		
		}catch(Exception e)
		{
			System.out.println(e);
		}
		}
		
	}

	@Override
	public void focusLost(FocusEvent fe) {
		// TODO Auto-generated method stub
		
		if(fe.getSource().equals(tf1))
		{
		if(tf1.getText().matches("^[0-9]+"))
		{
			msgl1.setVisible(false);
			f1=1;
		}
		else
		{
			msgl1.setVisible(true);
			msgl1.setForeground(Color.RED);
		}
		}
		if(fe.getSource().equals(tf2))
		{
		if(tf2.getText().matches("^[a-zA-Z ?]+"))
		{
			msgl2.setVisible(false);
			f2=1;
		}
		else
		{
			msgl2.setVisible(true);
			msgl2.setForeground(Color.RED);
		}
		}
		if(fe.getSource().equals(tf3))
		{
		if(tf3.getText().matches("^[0-9]+"))
		{
			msgl3.setVisible(false);
			f3=1;
		}
		else
		{
			msgl3.setVisible(true);
			msgl3.setForeground(Color.RED);
			
		}
		}
		if(fe.getSource().equals(tf5))
		{
		if(tf5.getText().matches("^[0-9]{10}"))
		{
			msgl4.setVisible(false);
			f4=1;
		}
		else
		{
			msgl4.setVisible(true);
			msgl4.setForeground(Color.RED);
		}
		}
		/*
		if(fe.getSource().equals(tf6))
		{
		if(tf6.getText().matches("^[a-zA-Z]+"))
		{
			msgl5.setVisible(false);
			f5=1;
		}
		else
		{
			msgl5.setVisible(true);
			msgl5.setForeground(Color.RED);
		}
		
		}
		*/
		
	}
	
	public void clear()
	{
		
		tf1.setText("");
		tf2.setText("");
		tf3.setText("");
		tf5.setText("");
		//tf6.setText("");
		rb1.setSelected(true);
		jcb.setSelectedItem("General Physician");
		jcb1.setSelectedItem("Married");
	}
	

	public void addData()
	{
		DefaultTableModel model=new DefaultTableModel();
		model.setColumnIdentifiers(colHeads);
		docTable=new JTable();
		docTable.setModel(model);
		jsp=new JScrollPane(docTable);
		
		int id,age,phone;
		String name="",gender="",spe="",mar="";
		
		try
		{
			
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hospitaldb","root","");
		if(con ==null)
			System.out.println("no connection");
		
		String sql="select * from doctor where Doc_id>0";
		PreparedStatement ps=con.prepareStatement(sql);
		ResultSet rs=ps.executeQuery();
		int i=0;
		while(rs.next())
		{
			id=rs.getInt("Doc_id");
			name=rs.getString("Name");
			age=rs.getInt("Age");
			gender=rs.getString("Gender");
			spe=rs.getString("Specialization");
			phone=rs.getInt("Phn_no");
			mar=rs.getString("Maritial_status");
			//joind=rs.getString("Joining_date");
			model.addRow(new Object[] {id,name,age,gender,spe,phone,mar});
			i++;
			
		}
				
		}catch(Exception e)
		{
			
		}
		
		
		
		
	}
	
	
	public void addData1()
	{
		DefaultTableModel model=new DefaultTableModel();
		model.setColumnIdentifiers(colHeads1);
		docTable1=new JTable();
		docTable1.setModel(model);
		jsp1=new JScrollPane(docTable1);
		
		int id,phone;
		String name="",email="",gender="",spe="",appoint="";
		
		try
		{
			
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hospitaldb","root","");
		if(con ==null)
			System.out.println("no connection");
		
		String sql="select * from patient where Pid>0";
		PreparedStatement ps=con.prepareStatement(sql);
		ResultSet rs=ps.executeQuery();
		int i=0;
		while(rs.next())
		{
			id=rs.getInt("Pid");
			name=rs.getString("Name");
			email=rs.getString("Email");
			phone=rs.getInt("Ph_no");
			gender=rs.getString("gender");
			spe=rs.getString("Specialist");
			appoint=rs.getString("Appointment");
			
			model.addRow(new Object[] {id,name,email,phone,gender,spe,appoint});
			i++;
			
		}
					
		}catch(Exception e)
		{
			
		}
		
		
		
		
	}
	
}
