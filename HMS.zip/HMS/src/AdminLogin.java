import java.awt.event.*;
import javax.swing.*;
import java.applet.*;
import java.awt.*;

public class AdminLogin extends JFrame implements ActionListener{

	JPanel mainp,head;
	JLabel log,txt,user,pass,l1;
	JTextField tf1;
	JPasswordField tf2;
	JButton login,bhome;
	JLabel message;
	AdminLogin(){
		
		
		setLayout(new BorderLayout());
		
		JLabel background=new JLabel(new ImageIcon("4.jpg"));
		//JLabel background=new JLabel();
		add(background);
		background.setLayout(null);
		add(background);
		head =new JPanel(null);
		head.setBackground(Color.BLUE);
		head.setBounds(0,25,1500,50);
		
		bhome=new JButton(new ImageIcon("Home-32.png"));
		bhome.setBounds(1300,8,40,40);
		head.add(bhome);
		bhome.addActionListener(this);
		
		l1=new JLabel("Hospital Management System",JLabel.CENTER);
		l1.setFont(new Font("Serif",Font.BOLD,30));
		l1.setBounds(500,2,400,50);
		head.add(l1);
		background.add(head);
		
		
		
		mainp=new JPanel(null);
	
		log=new JLabel("Login Here");
		log.setFont(new Font("Serif",Font.BOLD,30));
		txt=new JLabel("ADMIN LOGIN PANEL");
		txt.setFont(new Font("Serif",Font.BOLD,15));
		user=new JLabel("Username");
		user.setFont(new Font("Serif",Font.BOLD,15));
		pass=new JLabel("Password");
		pass.setFont(new Font("Serif",Font.BOLD,15));
		tf1=new JTextField();
		tf2=new JPasswordField();
		login=new JButton("Login");
		login.addActionListener(this);
		
		log.setBounds(60,30,180,40);
		mainp.add(log);
		txt.setBounds(60,75,180,30);
		mainp.add(txt);
		user.setBounds(60,140,180,30);
		mainp.add(user);
		pass.setBounds(60,200,180,30);
		mainp.add(pass);
		
		tf1.setBounds(250,140,180,30);
		mainp.add(tf1);
		tf2.setBounds(250,200,180,30);
		mainp.add(tf2);
		
		login.setBounds(150,270,100,30);
		mainp.add(login);
		mainp.setBackground(new Color(0, 204, 204));
		mainp.setBounds(400,200,500,400);
		background.add(mainp);
		
		
		message=new JLabel("");
		message.setBounds(100,310,300,30);
		mainp.add(message);
		
		setExtendedState(JFrame.MAXIMIZED_BOTH);
		
		
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		
		
		setVisible(true);
		
		
	}
	
	@Override
	public void actionPerformed(ActionEvent ae) {
		
		// TODO Auto-generated method stub
		if(ae.getSource()==bhome)
		{
			new Home();
			setVisible(false);
		}
		else
		{
		String ss1,ss2;
		if(tf1.getText().equals("")&&tf2.getText().equals(""))
		{
			message.setText("Please enter username and password");
		}
		else if(tf1.getText().equals("admin1")&&tf2.getText().equals("admin123"))
		{
			new Admin();
			this.dispose();
		}
		else if(tf1.getText().equals("admin1"))
		{
			message.setText("Please enter correct password");
		}
		else if(tf2.getText().equals("admin123"))
		{
			message.setText("Please enter correct password");
		}
		else
		{
			message.setText("Please enter correct username and password");
		}
	}
	}
}
