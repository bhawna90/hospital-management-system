import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class Doctors extends JFrame implements ActionListener{
	JTabbedPane jtp;
	JPanel p1,p2,ad,ad1,fm;
	JLabel doc,doc1,img,l1;
	JButton bdel,bhome,bhome1,refresh;
	JTextField tf1;
	
	
	JTable docTable1;
	JScrollPane jsp1;
	String[] colHeads1={"Patient id","Name","Email","Phone number","Gender","Specialist","Appointment"};

	
	Doctors(){
		jtp=new JTabbedPane();
		p1=new JPanel(null);
		p2=new JPanel(null);
		jtp.addTab("Check Details of Patients", p1);
		jtp.addTab("Delete Patient", p2);
		add(jtp);
		bhome=new JButton(new ImageIcon("Home-32.png"));
		bhome.setBounds(1300,30,40,40);
		p1.add(bhome);
		bhome.addActionListener(this);
		
		bhome1=new JButton(new ImageIcon("Home-32.png"));
		bhome1.setBounds(1300,30,40,40);
		p2.add(bhome1);
		bhome1.addActionListener(this);
		
		
		
		ad=new JPanel(null);
		ad.setBackground(Color.BLUE);
		ad.setBounds(0,25,1500,50);
		p1.add(ad);
		doc=new JLabel("View Patients");
		doc.setFont(new Font("Serif",Font.BOLD,20));
		doc.setBounds(40,10,200,30);
		ad.add(doc);
		
		refresh=new JButton("Refresh");
		refresh.setBounds(1200,15,80,20);
		ad.add(refresh);
		refresh.addActionListener(this);
		
		
		
		addData1();
		jsp1.setBounds(10,100,1330,800);
		p1.add(jsp1);
		
		
		
		
		
		ad1=new JPanel(null);
		ad1.setBackground(Color.BLUE);
		p2.add(ad1);
		ad1.setBounds(0,25,1500,50);
		doc1=new JLabel("Delete Patient");
		doc1.setFont(new Font("Serif",Font.BOLD,20));
		doc1.setBounds(40,10,200,30);
		ad1.add(doc1);
		p2.add(ad1);
		
		
		
		bdel=new JButton("DELETE");
		bdel.setBounds(585,450,100,40);
		p2.add(bdel);
		
		
		fm=new JPanel(null);
		fm.setBounds(390,170,500,400);
		p2.add(fm);
		fm.setBackground(new Color(0, 204, 204));
		
		img=new JLabel(new ImageIcon("appoint.png"));
		img.setBounds(100,50,300,128);
		fm.add(img);
		
		l1=new JLabel("ID of the patient");
		l1.setBounds(160,170,200,30);
		l1.setFont(new Font("Serif",Font.BOLD,20));
		fm.add(l1);
		tf1=new JTextField();
		tf1.setBounds(180,200,130,30);
		fm.add(tf1);
		
		
		bdel.addActionListener(this);
		
		setTitle("Doctors Panel");
		setExtendedState(JFrame.MAXIMIZED_BOTH);
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}

	

	@Override
	public void actionPerformed(ActionEvent ae) {
		// TODO Auto-generated method stub
		if(ae.getSource()==bdel)
		{
			
			try 
			{
				Class.forName("com.mysql.jdbc.Driver");
				Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hospitaldb","root","");
				if(con==null)
				{
					System.out.println("no connection");
					
				}
				int id;
				id=Integer.parseInt(tf1.getText());
				PreparedStatement stmt=con.prepareStatement("delete from patient where Pid =?");
				
				stmt.setInt(1,id);
				int i=stmt.executeUpdate();
				JOptionPane.showMessageDialog(null,"Your data is deleted");
				clear();
				con.close();
			
			}catch(Exception e)
			{
				System.out.println(e);
			}
				
		}
		else if(ae.getSource()==bhome||ae.getSource()==bhome1)
		{
			new Home();
			setVisible(false);
		}
		else if(ae.getSource()==refresh)
		{
			new Doctors();
			setVisible(false);
		}
		
		
	}
	
	public void clear()
	{
		tf1.setText("");
		
	}
	
	public void addData1()
	{
		DefaultTableModel model=new DefaultTableModel();
		model.setColumnIdentifiers(colHeads1);
		docTable1=new JTable();
		docTable1.setModel(model);
		jsp1=new JScrollPane(docTable1);
		
		int id,phone;
		String name="",email="",gender="",spe="",appoint="";
		
		try
		{
			
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hospitaldb","root","");
		if(con ==null)
			System.out.println("no connection");
		
		String sql="select * from patient where Pid>0";
		PreparedStatement ps=con.prepareStatement(sql);
		ResultSet rs=ps.executeQuery();
		int i=0;
		while(rs.next())
		{
			id=rs.getInt("Pid");
			name=rs.getString("Name");
			email=rs.getString("Email");
			phone=rs.getInt("Ph_no");
			gender=rs.getString("gender");
			spe=rs.getString("Specialist");
			appoint=rs.getString("Appointment");
			
			model.addRow(new Object[] {id,name,email,phone,gender,spe,appoint});
			i++;
			
		}
		
		
		
		if(i<1)
		{
			JOptionPane.showMessageDialog(null, "No Record Found");
		}
		
		
		int num=0;
		
		con.close();
			
		}catch(Exception e)
		{
			
		}
		
		
		
		
	}
	
	
}
