import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.*;
import javax.swing.*;
import java.applet.*;
import java.awt.*;

public class Home extends JFrame implements ActionListener {
	JPanel p1;
	JButton b1,b2,b3,b4,bhome;
	JLabel l1,l2,l3,l4;
	
	Home()
	{
		setLayout(new BorderLayout());
		
		JLabel background=new JLabel(new ImageIcon("4.jpg"));
		//JLabel background=new JLabel();
		add(background);
		background.setLayout(null);
		p1=new JPanel();
		l1=new JLabel("Hospital Management System",JLabel.CENTER);
		l1.setFont(new Font("Serif",Font.BOLD,30));
		p1.setBackground(Color.BLUE);
		b1=new JButton("Patient");
		b2=new JButton("Admin");
		b3=new JButton("Doctor");
		p1.setBounds(0,25,1500,50);
		p1.add(l1);
		background.add(p1);
		
		bhome=new JButton(new ImageIcon("Home-32.png"));
		bhome.setBounds(1300,30,40,40);
		background.add(bhome);
		bhome.addActionListener(this);
		/*
		b4=new JButton(new ImageIcon("back.jpg"));
		b4.setBounds(10,80,40,40);
		
		background.add(b4);
		
		b4.addActionListener(this);
		*/
		b1.setBounds(380,330,100,50);
		b2.setBounds(600,330,100,50);
		b3.setBounds(820,330,100,50);
	
		background.add(b1);
		background.add(b2);
		background.add(b3);
		
		setExtendedState(JFrame.MAXIMIZED_BOTH);
		
		l2=new JLabel(new ImageIcon("appoint.png"));
		l3=new JLabel(new ImageIcon("admin2.png"));
		l4=new JLabel(new ImageIcon("Doctoricon2.png"));
		background.add(l2);
		background.add(l3);
		background.add(l4);
		l2.setBounds(290,200,300,128);
		l3.setBounds(500,200,300,128);
		l4.setBounds(730,200,300,128);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		b1.addActionListener(this);
		b2.addActionListener(this);
		b3.addActionListener(this);
		
		setVisible(true);
		
	}
	public static void main(String args[])
	{
		new Home();
	}
	@Override
	public void actionPerformed(ActionEvent ae) {
		// TODO Auto-generated method stub
		
		if(ae.getSource()==b1)
			{
			
			new RegistrationFormDesign();
			this.dispose();
			
			}
		else if(ae.getSource()==b2)
		{
			new AdminLogin();
			this.dispose();
		}
		else if(ae.getSource()==b3)
		{
			new Doctors();
			this.dispose();
		 
		}
		
	}
	
}
