import javax.swing.*;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.*;

public class test extends JFrame implements FocusListener,ActionListener  {

JLabel l1,l2,l3,l4,l5,l6,l7,l11,l12,err1,err2,err3;
JPanel p1,p2;
JPanel p3,p4,p5,p6,p7,p8,p9,p11,p12,p13;
JFrame jf;
JButton b3,bhome;
JTextField tf1,tf2,tf3,tf4;
JRadioButton b1,b2;
JComboBox cb1,cb2;


//variables
String nameEntered,panEntered ,mailEntered,idEntered;

int flagmail;
int flagstr;
int flagphn;
String gender;


 test()
{
	 
	 setLayout( null);

	 bhome=new JButton(new ImageIcon("F:\\btechcsA5\\HMS\\Home-32.png"));
		bhome.setBounds(1300,30,40,40);
		add(bhome);
		bhome.addActionListener(this);
	 
		p11=new JPanel(new FlowLayout());
		l11=new JLabel("Hospital Management System",JLabel.CENTER);
		l11.setFont(new Font("Serif",Font.BOLD,30));
		l11.setBounds(550,5,300,50);
		p11.setBackground(Color.BLUE);
		p11.setBounds(0,25,1500,50);
	p11.add(l11);
	add(p11);

	setSize(1000,700);
	p1=new JPanel(new GridLayout(8,2));
	//p1.setSize(1000, 700);
	p1.setBackground(new Color(35, 181, 175));
	l1=new JLabel("Registration Form",JLabel.CENTER);
	l1.setFont(new Font("Serif",Font.BOLD,30));
	l1.setBounds(550,65,300,50);
	
	l12=new JLabel("Patient ID",JLabel.CENTER);
	l12.setFont(new Font("Serif",Font.BOLD,25));
	tf4=new JTextField();
	tf4.setBounds(10,20,400,27);
	p13=new JPanel(null);
	p13.add(tf4);
	//tf4.setEditable(false);
	p13.setBackground(new Color(35, 181, 175));
	

	l2=new JLabel("Name",JLabel.CENTER);
	l2.setFont(new Font("Serif",Font.BOLD,25));
	p3=new JPanel(null);
	tf1=new JTextField(15);
	tf1.setBounds(10,20,400,27);
	err1=new JLabel("* Enter only Character or Word");
	err1.setBounds(10,50,500,10);
	p3.setBackground(new Color(35, 181, 175));
	err1.setVisible(false);
	tf1.addFocusListener(this);
	p3.add(tf1);
	p3.add(err1);
	l3=new JLabel("Email Id",JLabel.CENTER);
	l3.setFont(new Font("Serif",Font.BOLD,25));
	p4=new JPanel(null);
	tf2=new JTextField(15);
	tf2.setBounds(10,20,400,27);
	err2=new JLabel("* Enter valid Mail id");
	err2.setBounds(10,50,500,10);
	p4.setBackground(new Color(35, 181, 175));
	err2.setVisible(false);
	tf2.addFocusListener(this);
	p4.add(tf2);
	p4.add(err2);

	l4=new JLabel("Phone no",JLabel.CENTER);
	l4.setFont(new Font("Serif",Font.BOLD,25));
	p5=new JPanel(null);
	tf3=new JTextField(15);
	tf3.setBounds(10,20,400,27);
	err3=new JLabel("* Enter only numbers");
	err3.setBounds(10,50,500,10);
	p5.setBackground(new Color(35, 181, 175));
	err3.setVisible(false);
	tf3.addFocusListener(this);
	p5.add(tf3);
	p5.add(err3);
	l5=new JLabel("Gender",JLabel.CENTER);
	l5.setFont(new Font("Serif",Font.BOLD,25));
	p6=new JPanel(null);
    b1=new JRadioButton("Male");
    b1.setBounds(20,20,80,27);
    b2=new JRadioButton("Female");
    b2.setBounds(100,20,80,27);
    p6.setBackground(new Color(35, 181, 175));
    ButtonGroup grp= new  ButtonGroup();
    grp.add(b1);
    grp.add(b2);
    p6.add(b1);
    p6.add(b2);
    b1.setSelected(true);
    
    l6=new JLabel("Specialist",JLabel.CENTER);
    l6.setFont(new Font("Serif",Font.BOLD,25));
    p7=new JPanel(null);
    cb1=new JComboBox();
    cb1.addItem("General Physician");
	cb1.addItem("Gynecologist");
	cb1.addItem("Pediatrician");
	cb1.addItem("Dermatologist");
	cb1.addItem("ENT Doctor");
	cb1.addItem("Cardiologist");
	cb1.addItem("Nuerologist");
	cb1.addItem("Dentist");
	cb1.addItem("Ophthalmologist");
    cb1.setBounds(10,20,400,27);
    p7.setBackground(new Color(35, 181, 175));
    p7.add(cb1);
    
    
    l7=new JLabel("Appointment",JLabel.CENTER);
    l7.setFont(new Font("Serif",Font.BOLD,25));
    p8=new JPanel(null);
    cb2=new JComboBox();
    cb2.addItem("11 A:M");
    cb2.addItem("2  P:M");
    cb2.addItem("4  P:M");
    cb2.setBounds(10,20,400,30);
    p8.setBackground(new Color(35, 181, 175));
    p8.add(cb2);
    p9=new JPanel(null);
    b3=new JButton("SUBMIT");
	b3.setBounds(350,20,100,30);
	b3.addActionListener(this);
	p9.setBackground(new Color(35, 181, 175));
	p9.add(b3);
	add(l1);
	p1.add(l12);
	p1.add(p13);
	p1.add(l2);
	p1.add(p3);
	p1.add(l3);
	p1.add(p4);
	p1.add(l4);
	p1.add(p5);
	p1.add(l5);
	p1.add(p6);
    p1.add(l6);
    p1.add(p7);
    p1.add(l7);
	p1.add(p8);
	
	p1.add(p9);
	p1.setBounds(200,120,1000,500);
	add(p1);
	setExtendedState(JFrame.MAXIMIZED_BOTH);
	setDefaultCloseOperation(EXIT_ON_CLOSE);
	setVisible(true);
}	
	public static void main(String args[])
	{
		new test();
		
	}
	
	@Override
	public void focusGained(FocusEvent fe) {
		// TODO Auto-generated method stub
		if(fe.getSource().equals(tf4))
		{
			int i=4;
			tf4.setText(i+"");
			JOptionPane.showMessageDialog(null,"focus gained");

			
			/*
			try
			{
				
				Class.forName("com.mysql.jdbc.Driver");
				Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hospitaldb","root","");
			if(con ==null)
				System.out.println("no connection");
			
			String sql="select * from patient where Pid>0";
			PreparedStatement ps=con.prepareStatement(sql);
			ResultSet rs=ps.executeQuery();
			int i=0;
			while(rs.next())
			{
				i++;
				
			}
			
			i++;
			tf4.setText(i+"");
			
			con.close();
				
			}catch(Exception e)
			{
				
			}
			*/
		}
		
	}
	@Override
	public void focusLost(FocusEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource().equals(tf1))
		{
            validationForName(tf1);			
			
			
		}
		if(e.getSource().equals(tf2))
		{
			
			validationForMail(tf2);
		}
		if(e.getSource().equals(tf3))
		{
			
			validationForPhone(tf3);
			
		}
			
		}
		private void validationForName(JTextField tf1) 
		{
			// TODO Auto-generated method stub
			String tx1=tf1.getText().trim();
			if(tx1.matches("^[a-zA-Z ?]+"))
			{
				flagstr=1;
				err1.setVisible(false);
			}
			else
			{flagstr=0;
			err1.setVisible(true);
			err1.setForeground(Color.RED);
			}
			
		}
		 private void validationForPhone(JTextField tf3) {
				// TODO Auto-generated method stub
				String tx2= tf3.getText().trim();
				
				if(tx2.matches("^[0-9]{10}"))
				{
					flagphn=1;
					err3.setVisible(false);
				}
				else
				{
					
					flagphn=0;
					err3.setVisible(true);
					err3.setForeground(Color.RED);
				}
			 }
			
				
			
		
		private void validationForMail(JTextField tf2) {
			// TODO Auto-generated method stub
			String tx3= tf2.getText().trim();
			if(tx3.matches("^[A-Za-z0-9_.-]+@(.+)$"))
			{
				flagmail=1;
				err2.setVisible(false);
			}
			else
			{
				flagmail=0;
				err2.setVisible(true);
				err2.setForeground(Color.RED);
			}
			
		}
		
	
	@Override
	public void actionPerformed(ActionEvent ae) {
		
		if(ae.getSource()==bhome)
		{
			new Home();
			setVisible(false);
		}
		else
		{
		
		 if((b1.isSelected()==true)) 
		{
			
			gender="male";
			
		}
		 else if ((b2.isSelected()==true))
		 {
			 
			 gender="female";
		 }
		
		 else
		 {
	if((b1.isSelected()==false) && (b2.isSelected()==false))
	{
		JOptionPane.showMessageDialog(null,"Please select Radio button");
	}
		 }
	
	if(flagmail == 1 && flagstr == 1 && flagphn == 1)
	{
		
		try{           
			idEntered=tf4.getText();
			nameEntered=tf1.getText().trim();
			 mailEntered =tf2.getText().trim();
			panEntered= tf3.getText().trim();
			JOptionPane.showMessageDialog(null,"Your Entered details are \n\nPatient id is="+idEntered+"\n\n Name is = "+nameEntered+"\n\n mail id = "+mailEntered+"\n\n phn_no = "+panEntered);
		}
		catch(NumberFormatException e){}

		try 
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hospitaldb","root","");
		if(con ==null)
			System.out.println("Hello");
		
		PreparedStatement stmt=con.prepareStatement("Insert into patient(Pid,Name,Email,Ph_no,gender,Specialist,Appointment) VALUES(?,?,?,?,?,?,?)");
		stmt.setInt(1, Integer.parseInt(tf4.getText()));
		stmt.setString(2, tf1.getText());
		stmt.setString(3, tf2.getText());
		stmt.setInt(4, Integer.parseInt(tf3.getText()));
		stmt.setString(5,gender);
		stmt.setString(6,(String) cb1.getSelectedItem());
		stmt.setString(7,(String) cb2.getSelectedItem());
		
		stmt.executeUpdate();
			
		clear();
		//tf4.setText(size+"");
		con.close();
		
		}catch(Exception e)
		{
			System.out.println(e);
		}
			
		
	}
		}

	}
	public void clear()
	{
		tf1.setText("");
		tf2.setText("");
		tf3.setText("");
		tf4.setText("");
		b1.setSelected(true);
		cb1.setSelectedItem("General Physician");
		cb2.setSelectedItem("11 A:M");
	}
	}
