import javax.swing.*;
import java.awt.*;
import java.text.*;
import java.util.Calendar;
//import org.jdesktop.swingx.JXDatePicker;

public class test1 extends JFrame{

	JButton b1;
	
	test1()
	{
		
		JPanel datePanel=new JPanel(new BorderLayout());
		DateFormat format=new SimpleDateFormat("yyyy--MMMM--dd");
		JFormattedTextField dateTextField=new JFormattedTextField(format);
		datePanel.add(dateTextField,BorderLayout.CENTER);
		add(datePanel,BorderLayout.NORTH);
		
		/*
		b1=new JButton("click here");
		add(b1);
		*/
		add(new JTextField(),BorderLayout.SOUTH);
		setTitle("test1");
		setSize(800,600);
		setLayout(new FlowLayout());
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);
	}
	
	public static void main(String args[])
	{
		new test1();
	}
}



